@echo off
gradle -Pandroid.useAndroidX=true -Pandroid.enableJetifier=true %*
