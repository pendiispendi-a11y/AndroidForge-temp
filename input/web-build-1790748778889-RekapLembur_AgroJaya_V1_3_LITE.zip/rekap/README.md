# Rekap Lembur - PT. Agro Jaya Perdana Jambi

Versi 1.3.

Fitur saat ini:
- 7 jam kerja efektif sebagai batas normal.
- Lembur = maksimal(0, kerja efektif - 7 jam).
- Pulang tepat pada batas 7 jam menghasilkan lembur 0 jam.
- Istirahat opsional: kosong berarti tidak ada pengurangan; diisi berarti dikurangi.
- Status harian: Hadir, Cuti, Izin Sakit, Izin P1, Mangkir.
- Status non-hadir dapat disimpan tanpa jam masuk/pulang.
- Logo perusahaan dan logo aplikasi.
- Penyimpanan lokal sementara.

Rencana tahap online: akun admin, akun anggota, database cloud dan sinkronisasi antar-HP.
