package com.agrojaya.rekaplembur;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    ArrayList<String> records = new ArrayList<>();

    @Override public void onCreate(Bundle b){ super.onCreate(b); load(); home(); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.DKGRAY); t.setPadding(12,12,12,12); return t;
    }
    Button bt(String s){ Button b=new Button(this); b.setText(s); return b; }

    void page(String h){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,12,18,18);
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        root.addView(tv("PT. AGRO JAYA PERDANA JAMBI",20));
        root.addView(tv("Palm Kernel Mills",13));
        root.addView(tv(h,24));
    }

    void home(){
        page("REKAP LEMBUR");
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_perusahaan); logo.setAdjustViewBounds(true);
        root.addView(logo,new LinearLayout.LayoutParams(-1,230));
        root.addView(tv("Jam kerja normal: 7 jam kerja efektif",16));
        root.addView(tv("Lembur dihitung otomatis setelah 7 jam efektif. Jika pulang tepat pada batas 7 jam, lembur = 0 jam.",14));
        root.addView(tv("Istirahat tidak wajib. Jika kosong, tidak ada pengurangan. Jika diisi, baru dikurangkan dari waktu kerja efektif.",13));

        Button a=bt("➕ INPUT LEMBUR / KEHADIRAN"); a.setOnClickListener(v->input()); root.addView(a);
        Button b=bt("👥 DATA KARYAWAN"); b.setOnClickListener(v->employees()); root.addView(b);
        Button c=bt("📋 REKAP HARIAN"); c.setOnClickListener(v->records()); root.addView(c);
        Button d=bt("📊 REKAP BULANAN"); d.setOnClickListener(v->records()); root.addView(d);
        Button e=bt("⚙️ PENGATURAN"); e.setOnClickListener(v->settings()); root.addView(e);
        root.addView(tv("Versi 1.3 • Status hadir/cuti/sakit/P1/mangkir + logo aplikasi.",12));
    }

    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); root.addView(e); return e;
    }

    void input(){
        page("INPUT KEHADIRAN / LEMBUR");
        EditText date=field("Tanggal (dd-mm-yyyy)");
        EditText name=field("Nama karyawan");
        EditText job=field("Jabatan / bagian");

        root.addView(tv("STATUS KEHADIRAN",15));
        Spinner status=new Spinner(this);
        String[] statuses={"Hadir","Cuti","Izin Sakit","Izin P1","Mangkir"};
        status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses));
        root.addView(status);

        EditText masuk=field("Jam masuk (HH:mm) — wajib jika Hadir");
        EditText rest=field("Istirahat (menit), opsional — kosong = tanpa istirahat");
        EditText pulang=field("Jam pulang (HH:mm) — wajib jika Hadir");
        EditText ket=field("Pekerjaan / keterangan");

        Button save=bt("SIMPAN & HITUNG LEMBUR");
        save.setOnClickListener(v->{
            try{
                String st=status.getSelectedItem().toString();
                String dateText=date.getText().toString().trim();
                String nameText=name.getText().toString().trim();
                String jobText=job.getText().toString().trim();
                if(dateText.isEmpty() || nameText.isEmpty()) throw new IllegalArgumentException();

                double ot=0;
                if(st.equals("Hadir")){
                    int start=mins(masuk.getText().toString());
                    int end=mins(pulang.getText().toString());
                    String restText=rest.getText().toString().trim();
                    int r=restText.isEmpty()?0:Integer.parseInt(restText);
                    if(r<0) throw new IllegalArgumentException();
                    int effective=end-start; if(effective<0) effective+=1440;
                    effective-=r; if(effective<0) effective=0;
                    ot=Math.max(0,effective-420)/60.0;
                }

                String otText=st.equals("Hadir") ? String.format(Locale.US,"%.2f jam",ot) : "-";
                String row=dateText+" | "+nameText+" | "+jobText+" | "+st+
                    " | Lembur: "+otText+" | "+ket.getText().toString().trim();
                records.add(row); saveData();
                Toast.makeText(this,"Data tersimpan. "+(st.equals("Hadir")?"Lembur: "+otText:"Status: "+st),Toast.LENGTH_LONG).show();
                home();
            }catch(Exception ex){
                Toast.makeText(this,"Periksa tanggal, status, dan format jam HH:mm.",Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(save);
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    int mins(String s){
        String[] p=s.trim().split(":");
        if(p.length!=2) throw new IllegalArgumentException();
        int h=Integer.parseInt(p[0]), m=Integer.parseInt(p[1]);
        if(h<0 || h>23 || m<0 || m>59) throw new IllegalArgumentException();
        return h*60+m;
    }

    void employees(){
        page("DATA KARYAWAN");
        root.addView(tv("Versi multi-HP berikutnya akan menyimpan akun anggota dan database online. Untuk versi ini, data masih tersimpan lokal pada perangkat.",16));
        root.addView(tv("Setiap catatan dapat berstatus Hadir, Cuti, Izin Sakit, Izin P1, atau Mangkir. Status non-hadir tidak membutuhkan jam masuk/pulang.",14));
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void records(){
        page("REKAP KEHADIRAN & LEMBUR");
        if(records.size()==0) root.addView(tv("Belum ada data.",18));
        else{
            for(int i=0;i<records.size();i++) root.addView(tv((i+1)+". "+records.get(i),15));
            Button clear=bt("HAPUS SEMUA DATA");
            clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Hapus data?")
                .setMessage("Semua rekap pada perangkat ini akan dihapus.")
                .setNegativeButton("Batal",null)
                .setPositiveButton("Hapus",(d,w)->{records.clear();saveData();records();}).show());
            root.addView(clear);
        }
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void settings(){
        page("PENGATURAN");
        root.addView(tv("Jam kerja normal: 7 jam efektif (420 menit)",17));
        root.addView(tv("Jika pulang tepat setelah 7 jam efektif, lembur = 0 jam. Istirahat hanya dihitung bila diisi.",14));
        root.addView(tv("Status non-hadir: Cuti, Izin Sakit, Izin P1, Mangkir — tanpa jam kerja.",14));
        root.addView(tv("ID iklan AdMob belum diisi. Dapat dipasang setelah akun AdMob siap.",14));
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void saveData(){ getSharedPreferences("data",MODE_PRIVATE).edit().putString("records",String.join("\n",records)).apply(); }
    void load(){ String s=getSharedPreferences("data",MODE_PRIVATE).getString("records",""); if(!s.isEmpty()) records.addAll(Arrays.asList(s.split("\\n"))); }
}
