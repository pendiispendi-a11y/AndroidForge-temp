# Rekap Lembur — PT. AGRO JAYA PERDANA JAMBI

MVP Android:
- 7 jam kerja efektif = jam normal.
- Selisih di atas 7 jam otomatis menjadi lembur.
- Istirahat dipisahkan dari jam kerja.
- Data rekap disimpan lokal di perangkat.
- Logo perusahaan disertakan.
- Struktur siap dikembangkan ke database, PDF, dan AdMob.

## Membuat APK
Buka folder proyek di Android Studio, lakukan Gradle Sync, lalu:
Build > Build APK(s)

APK debug akan berada di:
app/build/outputs/apk/debug/app-debug.apk

## Iklan
Proyek ini sengaja belum memakai ID iklan nyata. Setelah akun AdMob tersedia, gunakan ID aplikasi/ad unit resmi Anda dan tambahkan SDK sesuai dokumentasi Google. Jangan gunakan ID produksi saat pengujian.
