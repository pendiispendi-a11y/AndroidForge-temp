package com.agrojaya.rekaplembur;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private FirebaseAuth auth;
    private DatabaseReference db;
    private String role = "member";
    private String displayName = "";
    private static final String DB_URL = "https://rekap-lembur-agro-jaya-default-rtdb.asia-southeast1.firebasedatabase.app";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance(DB_URL).getReference();
        if (auth.getCurrentUser() == null) login(); else loadProfileAndHome();
    }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.DKGRAY); t.setPadding(12,10,12,10); return t;
    }
    TextView title(String s){ TextView t=tv(s,24); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    Button bt(String s){ Button b=new Button(this); b.setText(s); return b; }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(14,10,14,10); root.addView(e); return e; }

    void page(String h){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,12,18,18);
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        TextView company=tv("PT. AGRO JAYA PERDANA JAMBI",19); company.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(company);
        root.addView(tv("Palm Kernel Mills",13)); root.addView(title(h));
    }

    void login(){
        page("LOGIN REKAP LEMBUR");
        root.addView(tv("Data tersimpan online di Firebase. Gunakan akun masing-masing HP.",15));
        EditText email=field("Email"); email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=field("Password"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button masuk=bt("🔐 MASUK"); root.addView(masuk);
        Button daftar=bt("➕ DAFTAR AKUN ANGGOTA"); root.addView(daftar);
        TextView info=tv("Admin dibuat dari akun yang sudah terdaftar dengan mengubah role-nya menjadi admin di Firebase. Jangan membagikan akun admin.",12); root.addView(info);
        masuk.setOnClickListener(v->{
            String e=email.getText().toString().trim(), p=pass.getText().toString();
            if(e.isEmpty()||p.isEmpty()){toast("Email dan password wajib diisi.");return;}
            auth.signInWithEmailAndPassword(e,p).addOnCompleteListener(this,t->{
                if(t.isSuccessful()) loadProfileAndHome(); else toast("Login gagal: "+(t.getException()!=null?t.getException().getMessage():"periksa akun"));
            });
        });
        daftar.setOnClickListener(v->register());
    }

    void register(){
        page("DAFTAR AKUN ANGGOTA");
        root.addView(tv("Akun anggota dipakai di HP masing-masing. Setelah terdaftar, akun dapat mengisi kehadiran/lembur sendiri.",14));
        EditText name=field("Nama lengkap");
        EditText email=field("Email"); email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=field("Password (minimal 6 karakter)"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button daftar=bt("DAFTAR & SIMPAN ONLINE"); root.addView(daftar);
        Button back=bt("KEMBALI KE LOGIN"); root.addView(back);
        daftar.setOnClickListener(v->{
            String n=name.getText().toString().trim(), e=email.getText().toString().trim(), p=pass.getText().toString();
            if(n.isEmpty()||e.isEmpty()||p.length()<6){toast("Nama, email, dan password minimal 6 karakter wajib diisi.");return;}
            auth.createUserWithEmailAndPassword(e,p).addOnCompleteListener(this,t->{
                if(!t.isSuccessful()){toast("Pendaftaran gagal: "+(t.getException()!=null?t.getException().getMessage():"coba lagi"));return;}
                FirebaseUser u=auth.getCurrentUser();
                if(u==null){toast("Akun dibuat, tetapi sesi belum tersedia.");return;}
                HashMap<String,Object> profile=new HashMap<>(); profile.put("name",n); profile.put("email",e); profile.put("role","member"); profile.put("companyId","agro-jaya");
                db.child("users").child(u.getUid()).setValue(profile).addOnCompleteListener(x->{
                    if(x.isSuccessful()){displayName=n;role="member";home();toast("Akun anggota berhasil dibuat.");}
                    else toast("Akun dibuat tetapi profil gagal disimpan: "+(x.getException()!=null?x.getException().getMessage():"coba lagi"));
                });
            });
        });
        back.setOnClickListener(v->login());
    }

    void loadProfileAndHome(){
        FirebaseUser u=auth.getCurrentUser(); if(u==null){login();return;}
        db.child("users").child(u.getUid()).addListenerForSingleValueEvent(new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot s){
                displayName=s.child("name").getValue(String.class); if(displayName==null) displayName=u.getEmail();
                String r=s.child("role").getValue(String.class); role=r==null?"member":r; home();
            }
            @Override public void onCancelled(DatabaseError e){toast("Profil tidak dapat dibaca: "+e.getMessage()); home();}
        });
    }

    void home(){
        page("REKAP LEMBUR");
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_perusahaan); logo.setAdjustViewBounds(true); root.addView(logo,new LinearLayout.LayoutParams(-1,300));
        root.addView(tv("👤 "+displayName+"   •   "+(role.equals("admin")?"ADMIN":"ANGGOTA"),15));
        root.addView(tv("☁️ Terhubung ke database online Firebase",13));
        root.addView(tv("Jam kerja normal: 7 jam kerja efektif. Istirahat hanya dikurangi jika diisi.",14));
        Button a=bt("➕ INPUT KEHADIRAN / LEMBUR"); a.setOnClickListener(v->input()); root.addView(a);
        Button b=bt("📋 REKAP DATA ONLINE"); b.setOnClickListener(v->records()); root.addView(b);
        Button c=bt("👥 DATA KARYAWAN"); c.setOnClickListener(v->employees()); root.addView(c);
        Button d=bt("⚙️ PENGATURAN"); d.setOnClickListener(v->settings()); root.addView(d);
        Button out=bt("🚪 KELUAR"); out.setOnClickListener(v->{auth.signOut();login();}); root.addView(out);
        root.addView(tv("Versi 1.5 Online • Firebase Authentication + Realtime Database",12));
    }

    void input(){
        page("INPUT ABSENSI & LEMBUR");
        root.addView(tv("Lembur dihitung dari waktu efektif di atas 7 jam. Jika istirahat kosong, tidak ada pengurangan.",13));
        EditText date=field("Tanggal (dd-mm-yyyy)"); EditText name=field("Nama karyawan"); EditText job=field("Jabatan / bagian");
        root.addView(tv("STATUS KEHADIRAN",15)); Spinner status=new Spinner(this);
        String[] statuses={"Hadir","Cuti","Izin Sakit","Izin P1","Mangkir"}; status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses)); root.addView(status);
        EditText masuk=field("Jam masuk (HH:mm) — wajib jika Hadir"); EditText restIn=field("Jam mulai istirahat (HH:mm), opsional"); EditText restOut=field("Jam selesai istirahat (HH:mm), opsional"); EditText restMin=field("Atau total istirahat (menit), opsional"); EditText pulang=field("Jam pulang (HH:mm) — wajib jika Hadir"); EditText ket=field("Keterangan / pekerjaan");
        Button save=bt("☁️ SIMPAN ONLINE & HITUNG LEMBUR"); root.addView(save);
        save.setOnClickListener(v->{
            try{
                String st=status.getSelectedItem().toString(), dateText=date.getText().toString().trim(), nameText=name.getText().toString().trim(), jobText=job.getText().toString().trim();
                if(dateText.isEmpty()||nameText.isEmpty()) throw new IllegalArgumentException();
                int effective=0, breakMinutes=0;
                String inText="-",outText="-";
                if(st.equals("Hadir")){
                    int start=mins(masuk.getText().toString()), end=mins(pulang.getText().toString()); inText=masuk.getText().toString().trim(); outText=pulang.getText().toString().trim();
                    int span=end-start; if(span<0) span+=1440;
                    String rin=restIn.getText().toString().trim(), rout=restOut.getText().toString().trim(), rmin=restMin.getText().toString().trim();
                    if(!rin.isEmpty()||!rout.isEmpty()){ if(rin.isEmpty()||rout.isEmpty()) throw new IllegalArgumentException(); breakMinutes=mins(rout)-mins(rin); if(breakMinutes<0) breakMinutes+=1440; }
                    else if(!rmin.isEmpty()) breakMinutes=Integer.parseInt(rmin);
                    if(breakMinutes<0||breakMinutes>span) throw new IllegalArgumentException();
                    effective=Math.max(0,span-breakMinutes);
                }
                int overtime=Math.max(0,effective-420); FirebaseUser u=auth.getCurrentUser(); if(u==null){login();return;}
                String key=db.child("records").child(u.getUid()).push().getKey(); if(key==null) throw new IllegalArgumentException();
                HashMap<String,Object> rec=new HashMap<>(); rec.put("uid",u.getUid()); rec.put("companyId","agro-jaya"); rec.put("date",dateText); rec.put("name",nameText); rec.put("job",jobText); rec.put("status",st); rec.put("jamMasuk",inText); rec.put("jamPulang",outText); rec.put("istirahatMenit",breakMinutes); rec.put("efektifMenit",effective); rec.put("lemburMenit",overtime); rec.put("keterangan",ket.getText().toString().trim()); rec.put("createdAt",System.currentTimeMillis());
                db.child("records").child(u.getUid()).child(key).setValue(rec).addOnCompleteListener(this,x->{ if(x.isSuccessful()){toast("Data berhasil disimpan online. Lembur: "+formatHours(overtime));home();}else toast("Gagal menyimpan: "+(x.getException()!=null?x.getException().getMessage():"coba lagi")); });
            }catch(Exception ex){toast("Periksa tanggal dan jam HH:mm. Untuk Cuti/Sakit/P1/Mangkir, jam kerja tidak perlu diisi.");}
        });
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void records(){
        page(role.equals("admin")?"REKAP SEMUA DATA ONLINE":"REKAP DATA SAYA");
        FirebaseUser u=auth.getCurrentUser(); if(u==null){login();return;}
        Query q=role.equals("admin")?db.child("records"):db.child("records").child(u.getUid());
        q.addListenerForSingleValueEvent(new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snap){
                if(!snap.exists()){root.addView(tv("Belum ada data online.",17));return;}
                ArrayList<String> lines=new ArrayList<>(); for(DataSnapshot x:snap.getChildren()){
                    String s=x.child("date").getValue(String.class)+" | "+x.child("name").getValue(String.class)+" | "+x.child("job").getValue(String.class)+" | "+x.child("status").getValue(String.class)+" | Masuk: "+x.child("jamMasuk").getValue(String.class)+" | Pulang: "+x.child("jamPulang").getValue(String.class)+" | Lembur: "+formatHours(intVal(x.child("lemburMenit")))+" | "+x.child("keterangan").getValue(String.class);
                    lines.add(s);
                }
                Collections.reverse(lines); int i=1; for(String s:lines) root.addView(tv((i++)+". "+s,14));
            }
            @Override public void onCancelled(DatabaseError e){root.addView(tv("Gagal membaca database: "+e.getMessage(),14));}
        });
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    int intVal(DataSnapshot s){ Long v=s.getValue(Long.class); return v==null?0:v.intValue(); }
    void employees(){ page("DATA KARYAWAN"); root.addView(tv("Mode online: setiap anggota memakai HP dan akun sendiri. Admin dapat membaca seluruh rekap.",15)); root.addView(tv("Status: Hadir, Cuti, Izin Sakit, Izin P1, Mangkir.",14)); Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back); }
    void settings(){ page("PENGATURAN"); root.addView(tv("Perusahaan: PT. AGRO JAYA PERDANA JAMBI",15)); root.addView(tv("Jam kerja normal: 7 jam efektif (420 menit)",15)); root.addView(tv("Istirahat kosong = tidak ada pengurangan. Jika diisi, baru dikurangi.",14)); root.addView(tv("Akun saat ini: "+displayName+" • role: "+role,14)); Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back); }

    String formatHours(int minutes){ if(minutes<=0)return "0 jam"; int h=minutes/60,m=minutes%60; return m==0?h+" jam":h+" jam "+m+" menit"; }
    int mins(String s){ String[] p=s.trim().split(":"); if(p.length!=2)throw new IllegalArgumentException(); int h=Integer.parseInt(p[0]),m=Integer.parseInt(p[1]); if(h<0||h>23||m<0||m>59)throw new IllegalArgumentException(); return h*60+m; }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
