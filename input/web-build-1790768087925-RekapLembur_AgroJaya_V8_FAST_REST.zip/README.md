# Rekap Lembur Agro Jaya — Online REST Edition

This build uses Firebase Authentication REST API and Firebase Realtime Database REST API directly.
It intentionally has **no Firebase Android SDK dependencies**, avoiding the AndroidX dependency chain that broke AndroidForge builds.

## Firebase configuration
- Project: rekap-lembur-agro-jaya
- Database region: Singapore (asia-southeast1)
- Package: com.agrojaya.rekaplembur
- Email/Password authentication: enabled
- Realtime Database URL is embedded in MainActivity.
- Firebase Web API key is the public client API key from google-services.json.

## Roles
- Registration always creates `member`.
- Admin can be created manually in Realtime Database by changing `users/<UID>/role` from `member` to `admin`.

## Database rules
Use `firebase_rules.json` from this project. Member accounts can create their own records; admin can read all records.

## Overtime rule
- Normal effective work = 7 hours / 420 minutes.
- Overtime is calculated **only when an explicit break/istirahat value is entered**.
- If break is blank, overtime is 0.
- Cuti, Izin Sakit, Izin P1, and Mangkir do not require work hours.
