package com.agrojaya.rekaplembur;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Rekap Lembur - REST edition.
 * Uses Firebase Authentication REST API and Realtime Database REST API directly.
 * No Firebase Android SDK dependency is used, so this project has no Firebase/AndroidX
 * runtime dependency chain for AndroidForge to resolve.
 */
public class MainActivity extends Activity {
    private static final String API_KEY = "AIzaSyAKx60acb_kpokLhzMj-cIkz4Y9qSGnFo4";
    private static final String DB_URL = "https://rekap-lembur-agro-jaya-default-rtdb.asia-southeast1.firebasedatabase.app";
    private static final String AUTH_URL = "https://identitytoolkit.googleapis.com/v1";
    private static final String TOKEN_URL = "https://securetoken.googleapis.com/v1/token";
    private static final String PREF = "rekap_session";

    private LinearLayout root;
    private SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private String role = "member";
    private String displayName = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (prefs.getString("refreshToken", "").isEmpty()) login();
        else loadProfileAndHome();
    }

    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }

    TextView tv(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(12,10,12,10); return t;
    }
    TextView title(String s) { TextView t=tv(s,24); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    Button bt(String s) { Button b=new Button(this); b.setText(s); return b; }
    EditText field(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setPadding(14,10,14,10); root.addView(e); return e; }

    void page(String h) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,12,18,18);
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        TextView company=tv("PT. AGRO JAYA PERDANA JAMBI",19); company.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(company);
        root.addView(tv("Palm Kernel Mills",13)); root.addView(title(h));
    }

    void login() {
        page("LOGIN REKAP LEMBUR • ONLINE");
        root.addView(tv("Online via Firebase REST API. Setiap HP memakai akun masing-masing.",15));
        EditText email=field("Email"); email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=field("Password"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button masuk=bt("🔐 MASUK"); root.addView(masuk);
        Button daftar=bt("➕ DAFTAR AKUN ANGGOTA"); root.addView(daftar);
        root.addView(tv("Admin dibuat dengan mengubah role akun menjadi admin di Firebase Console. Jangan membagikan akun admin.",12));
        masuk.setOnClickListener(v -> {
            String e=email.getText().toString().trim(), p=pass.getText().toString();
            if(e.isEmpty()||p.isEmpty()){toast("Email dan password wajib diisi.");return;}
            setBusy(masuk,true,"Masuk...");
            io.execute(() -> {
                try { JSONObject r=authPost("accounts:signInWithPassword",e,p); saveSession(r); runUi(this::loadProfileAndHome); }
                catch(Exception ex){ runUi(() -> { setBusy(masuk,false,"🔐 MASUK"); toast("Login gagal: "+friendly(ex)); }); }
            });
        });
        daftar.setOnClickListener(v->register());
    }

    void register() {
        page("DAFTAR AKUN ANGGOTA");
        root.addView(tv("Akun anggota dipakai di HP masing-masing. Data kehadiran/lembur tersimpan online.",14));
        EditText name=field("Nama lengkap");
        EditText email=field("Email"); email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=field("Password (minimal 6 karakter)"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button daftar=bt("DAFTAR & SIMPAN ONLINE"); root.addView(daftar);
        Button back=bt("KEMBALI KE LOGIN"); root.addView(back);
        daftar.setOnClickListener(v->{
            String n=name.getText().toString().trim(), e=email.getText().toString().trim(), p=pass.getText().toString();
            if(n.isEmpty()||e.isEmpty()||p.length()<6){toast("Nama, email, dan password minimal 6 karakter wajib diisi.");return;}
            setBusy(daftar,true,"Mendaftarkan...");
            io.execute(() -> {
                try {
                    JSONObject r=authPost("accounts:signUp",e,p); saveSession(r);
                    String uid=r.getString("localId");
                    JSONObject profile=new JSONObject(); profile.put("name",n); profile.put("email",e); profile.put("role","member"); profile.put("companyId","agro-jaya");
                    dbPut("users/"+uid,profile);
                    displayName=n; role="member"; runUi(()->{setBusy(daftar,false,"DAFTAR & SIMPAN ONLINE"); home(); toast("Akun anggota berhasil dibuat.");});
                } catch(Exception ex){ runUi(()->{setBusy(daftar,false,"DAFTAR & SIMPAN ONLINE"); toast("Pendaftaran gagal: "+friendly(ex));}); }
            });
        });
        back.setOnClickListener(v->login());
    }

    void loadProfileAndHome() {
        io.execute(() -> {
            try {
                ensureFreshToken();
                JSONObject p=dbGet("users/"+uid());
                displayName=p.optString("name",prefs.getString("email","")); role=p.optString("role","member");
                runUi(this::home);
            } catch(Exception ex){ clearSession(); runUi(()->{toast("Sesi tidak valid. Silakan login lagi."); login();}); }
        });
    }

    void home() {
        page("REKAP LEMBUR");
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_perusahaan); logo.setAdjustViewBounds(true); root.addView(logo,new LinearLayout.LayoutParams(-1,300));
        root.addView(tv("👤 "+displayName+"   •   "+(role.equals("admin")?"ADMIN":"ANGGOTA"),15));
        root.addView(tv("☁️ Database online • Firebase REST API",13));
        root.addView(tv("Jam kerja normal: 7 jam kerja efektif. Istirahat hanya dikurangi jika diisi.",14));
        Button a=bt("➕ INPUT KEHADIRAN / LEMBUR"); a.setOnClickListener(v->input()); root.addView(a);
        Button b=bt("📋 REKAP DATA ONLINE"); b.setOnClickListener(v->records()); root.addView(b);
        Button c=bt("👥 DATA KARYAWAN"); c.setOnClickListener(v->employees()); root.addView(c);
        Button d=bt("⚙️ PENGATURAN"); d.setOnClickListener(v->settings()); root.addView(d);
        Button out=bt("🚪 KELUAR"); out.setOnClickListener(v->{clearSession();login();}); root.addView(out);
        root.addView(tv("VERSI 1.5 ONLINE REST • Tanpa Firebase Android SDK",12));
    }

    void input() {
        page("INPUT ABSENSI & LEMBUR");
        root.addView(tv("Aturan: lembur dihitung hanya jika jam istirahat diisi. Jika istirahat kosong, lembur otomatis = 0.",13));
        EditText date=field("Tanggal (dd-mm-yyyy)"); EditText name=field("Nama karyawan"); EditText job=field("Jabatan / bagian");
        root.addView(tv("STATUS KEHADIRAN",15)); Spinner status=new Spinner(this);
        String[] statuses={"Hadir","Cuti","Izin Sakit","Izin P1","Mangkir"}; status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses)); root.addView(status);
        EditText masuk=field("Jam masuk (HH:mm) — wajib jika Hadir"); EditText restIn=field("Jam mulai istirahat (HH:mm), opsional"); EditText restOut=field("Jam selesai istirahat (HH:mm), opsional"); EditText restMin=field("Atau total istirahat (menit), opsional"); EditText pulang=field("Jam pulang (HH:mm) — wajib jika Hadir"); EditText ket=field("Keterangan / pekerjaan");
        Button save=bt("☁️ SIMPAN ONLINE & HITUNG LEMBUR"); root.addView(save);
        save.setOnClickListener(v->{
            try {
                String st=status.getSelectedItem().toString(), dateText=date.getText().toString().trim(), nameText=name.getText().toString().trim(), jobText=job.getText().toString().trim();
                if(dateText.isEmpty()||nameText.isEmpty()) throw new IllegalArgumentException();
                int effective=0, breakMinutes=0, overtime=0; String inText="-",outText="-";
                if(st.equals("Hadir")) {
                    int start=mins(masuk.getText().toString()), end=mins(pulang.getText().toString()); inText=masuk.getText().toString().trim(); outText=pulang.getText().toString().trim();
                    String rin=restIn.getText().toString().trim(), rout=restOut.getText().toString().trim(), rmin=restMin.getText().toString().trim();
                    boolean hasBreak=!rin.isEmpty()||!rout.isEmpty()||!rmin.isEmpty();
                    if(!hasBreak){ effective=0; overtime=0; }
                    else {
                        int span=end-start; if(span<0) span+=1440;
                        if(!rin.isEmpty()||!rout.isEmpty()){ if(rin.isEmpty()||rout.isEmpty()) throw new IllegalArgumentException(); breakMinutes=mins(rout)-mins(rin); if(breakMinutes<0) breakMinutes+=1440; }
                        else breakMinutes=Integer.parseInt(rmin);
                        if(breakMinutes<0||breakMinutes>span) throw new IllegalArgumentException();
                        effective=Math.max(0,span-breakMinutes); overtime=Math.max(0,effective-420);
                    }
                }
                final int fOvertime=overtime, fEffective=effective, fBreak=breakMinutes; final String fIn=inText,fOut=outText,fStatus=st,fDate=dateText,fName=nameText,fJob=jobText,fKet=ket.getText().toString().trim();
                setBusy(save,true,"Menyimpan...");
                io.execute(()->{
                    try {
                        ensureFreshToken();
                        JSONObject rec=new JSONObject(); rec.put("uid",uid()); rec.put("companyId","agro-jaya"); rec.put("date",fDate); rec.put("name",fName); rec.put("job",fJob); rec.put("status",fStatus); rec.put("jamMasuk",fIn); rec.put("jamPulang",fOut); rec.put("istirahatMenit",fBreak); rec.put("efektifMenit",fEffective); rec.put("lemburMenit",fOvertime); rec.put("keterangan",fKet); rec.put("createdAt",System.currentTimeMillis());
                        String key="r"+System.currentTimeMillis(); dbPut("records/"+uid()+"/"+key,rec);
                        runUi(()->{setBusy(save,false,"☁️ SIMPAN ONLINE & HITUNG LEMBUR"); toast("Data tersimpan. Lembur: "+formatHours(fOvertime)); home();});
                    } catch(Exception ex){runUi(()->{setBusy(save,false,"☁️ SIMPAN ONLINE & HITUNG LEMBUR");toast("Gagal menyimpan: "+friendly(ex));});}
                });
            } catch(Exception ex){toast("Periksa tanggal dan jam HH:mm. Untuk Cuti/Sakit/P1/Mangkir, jam kerja tidak perlu diisi.");}
        });
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void records() {
        page(role.equals("admin")?"REKAP SEMUA DATA ONLINE":"REKAP DATA SAYA");
        TextView loading=tv("Memuat data online...",14); root.addView(loading);
        io.execute(()->{
            try {
                ensureFreshToken(); JSONObject snap=dbGet(role.equals("admin")?"records":"records/"+uid());
                runUi(()->{root.removeView(loading); renderRecords(snap);});
            } catch(Exception ex){runUi(()->{loading.setText("Gagal membaca database: "+friendly(ex));});}
        });
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void renderRecords(JSONObject snap) {
        if(snap==null||snap.length()==0){root.addView(tv("Belum ada data online.",17));return;}
        ArrayList<String> lines=new ArrayList<>(); Iterator<String> outer=snap.keys();
        try {
            if(role.equals("admin")) {
                while(outer.hasNext()){String member=outer.next(); JSONObject rs=snap.optJSONObject(member); if(rs==null)continue; Iterator<String> ks=rs.keys(); while(ks.hasNext()) lines.add(formatRecord(rs.optJSONObject(ks.next())));}
            } else { while(outer.hasNext()) lines.add(formatRecord(snap.optJSONObject(outer.next()))); }
        } catch(Exception ignored){}
        Collections.reverse(lines); int i=1; for(String s:lines) root.addView(tv((i++)+". "+s,14));
    }

    String formatRecord(JSONObject x){ if(x==null)return ""; return x.optString("date")+" | "+x.optString("name")+" | "+x.optString("job")+" | "+x.optString("status")+" | Masuk: "+x.optString("jamMasuk")+" | Pulang: "+x.optString("jamPulang")+" | Lembur: "+formatHours(x.optInt("lemburMenit",0))+" | "+x.optString("keterangan"); }
    void employees(){page("DATA KARYAWAN");root.addView(tv("Mode online: setiap anggota memakai HP dan akun sendiri. Admin membaca seluruh rekap.",15));root.addView(tv("Status: Hadir, Cuti, Izin Sakit, Izin P1, Mangkir.",14));Button back=bt("KEMBALI");back.setOnClickListener(v->home());root.addView(back);}
    void settings(){page("PENGATURAN");root.addView(tv("Perusahaan: PT. AGRO JAYA PERDANA JAMBI",15));root.addView(tv("Jam kerja normal: 7 jam efektif (420 menit)",15));root.addView(tv("Istirahat kosong = lembur otomatis 0. Jika istirahat diisi, baru dihitung.",14));root.addView(tv("Akun: "+displayName+" • role: "+role,14));Button back=bt("KEMBALI");back.setOnClickListener(v->home());root.addView(back);}

    JSONObject authPost(String method,String email,String password)throws Exception{
        JSONObject body=new JSONObject();body.put("email",email);body.put("password",password);body.put("returnSecureToken",true);return httpJson("POST",AUTH_URL+"/"+method+"?key="+url(API_KEY),body.toString(),null);
    }
    void saveSession(JSONObject r)throws Exception{prefs.edit().putString("idToken",r.getString("idToken")).putString("refreshToken",r.getString("refreshToken")).putString("uid",r.getString("localId")).putString("email",r.optString("email","")).putLong("expiresAt",System.currentTimeMillis()+Math.max(300,r.optInt("expiresIn",3600)-60)*1000L).apply();}
    void ensureFreshToken()throws Exception{
        if(System.currentTimeMillis()<prefs.getLong("expiresAt",0))return;
        String rt=prefs.getString("refreshToken","");if(rt.isEmpty())throw new IOException("Sesi habis");
        String form="grant_type=refresh_token&refresh_token="+url(rt);String raw=httpRaw("POST",TOKEN_URL+"?key="+url(API_KEY),form,"application/x-www-form-urlencoded");JSONObject r=new JSONObject(raw);
        prefs.edit().putString("idToken",r.getString("id_token")).putString("refreshToken",r.optString("refresh_token",rt)).putLong("expiresAt",System.currentTimeMillis()+Math.max(300,r.optInt("expires_in",3600)-60)*1000L).apply();
    }
    String uid(){return prefs.getString("uid","");}
    String token(){return prefs.getString("idToken","");}
    JSONObject dbGet(String path)throws Exception{return httpJson("GET",DB_URL+"/"+path+".json?auth="+url(token()),null, null);}
    void dbPut(String path,JSONObject body)throws Exception{httpJson("PUT",DB_URL+"/"+path+".json?auth="+url(token()),body.toString(),"application/json");}

    JSONObject httpJson(String method,String u,String body,String contentType)throws Exception{return new JSONObject(httpRaw(method,u,body,contentType));}
    String httpRaw(String method,String u,String body,String contentType)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setUseCaches(false);
        if(contentType!=null)c.setRequestProperty("Content-Type",contentType);if(body!=null){c.setDoOutput(true);OutputStream os=c.getOutputStream();os.write(body.getBytes("UTF-8"));os.close();}
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String s=read(in);c.disconnect();if(code<200||code>=300)throw new IOException(extractError(s,code));return s;
    }
    String read(InputStream in)throws Exception{if(in==null)return "";BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String l;while((l=br.readLine())!=null)b.append(l);br.close();return b.toString();}
    String extractError(String s,int code){try{JSONObject j=new JSONObject(s);JSONObject e=j.optJSONObject("error");if(e!=null)return e.optString("message","HTTP "+code);}catch(Exception ignored){}return "HTTP "+code;}
    String friendly(Exception e){String m=e.getMessage();if(m==null)return "terjadi kesalahan";return m.replace("EMAIL_NOT_FOUND","email tidak ditemukan").replace("INVALID_PASSWORD","password salah").replace("EMAIL_EXISTS","email sudah terdaftar").replace("WEAK_PASSWORD : Password should be at least 6 characters","password minimal 6 karakter").replace("INVALID_EMAIL","format email tidak valid");}
    String url(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    void clearSession(){prefs.edit().clear().apply();role="member";displayName="";}
    void runUi(Runnable r){runOnUiThread(r);}
    void setBusy(Button b,boolean busy,String text){b.setEnabled(!busy);b.setText(text);}
    String formatHours(int minutes){if(minutes<=0)return "0 jam";int h=minutes/60,m=minutes%60;return m==0?h+" jam":h+" jam "+m+" menit";}
    int mins(String s){String[] p=s.trim().split(":");if(p.length!=2)throw new IllegalArgumentException();int h=Integer.parseInt(p[0]),m=Integer.parseInt(p[1]);if(h<0||h>23||m<0||m>59)throw new IllegalArgumentException();return h*60+m;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
