# Rekap Lembur Agro Jaya - V1.5 Online

Firebase sudah dipasang menggunakan `google-services.json` untuk package `com.agrojaya.rekaplembur`.

Fitur:
- Firebase Authentication email/password
- Realtime Database online
- Akun anggota per HP
- Role admin untuk membaca seluruh rekap
- Input Hadir/Cuti/Izin Sakit/Izin P1/Mangkir
- Perhitungan lembur 7 jam efektif; istirahat hanya dikurangi jika diisi

Sebelum dipakai:
1. Firebase Console > Authentication > Sign-in method > aktifkan Email/Password.
2. Realtime Database > Rules: gunakan isi `firebase_rules.json`.
3. Daftarkan akun pertama melalui aplikasi. Untuk menjadikannya admin, ubah `users/<UID>/role` dari `member` menjadi `admin` di Realtime Database.
4. Jangan membagikan `google-services.json` ke orang lain yang tidak perlu.

## AndroidForge AndroidX workaround (V1.5-online-V5)
The project forces `android.useAndroidX=true` and `android.enableJetifier=true` through Gradle `startParameter.projectProperties` in `settings.gradle`, so the flags are available as Gradle project properties even if AndroidForge does not preserve or honor the extracted project's `gradle.properties`.
