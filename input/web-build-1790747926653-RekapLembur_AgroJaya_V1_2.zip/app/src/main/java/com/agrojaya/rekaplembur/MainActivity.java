package com.agrojaya.rekaplembur;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    ArrayList<String> records = new ArrayList<>();
    final int BLUE=Color.rgb(21,101,192);

    @Override public void onCreate(Bundle b){ super.onCreate(b); load(); home(); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.DKGRAY); t.setPadding(12,12,12,12); return t;
    }
    Button bt(String s){ Button b=new Button(this); b.setText(s); return b; }

    void page(String h){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,12,18,18);
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        root.addView(tv("PT. AGRO JAYA PERDANA JAMBI",20));
        root.addView(tv("Palm Kernel Mills",13));
        root.addView(tv(h,24));
    }

    void home(){
        page("REKAP LEMBUR");
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_perusahaan); logo.setAdjustViewBounds(true);
        root.addView(logo,new LinearLayout.LayoutParams(-1,230));
        root.addView(tv("Jam kerja normal: 7 jam kerja efektif",16));
        root.addView(tv("Lembur dihitung otomatis setelah 7 jam efektif.",14));
        root.addView(tv("Istirahat tidak wajib. Jika kolom istirahat kosong, tidak ada waktu yang dikurangi. Jika diisi, waktu tersebut baru dikurangkan dari jam kerja efektif.",13));

        Button a=bt("➕ INPUT LEMBUR"); a.setOnClickListener(v->input()); root.addView(a);
        Button b=bt("👥 DATA KARYAWAN"); b.setOnClickListener(v->employees()); root.addView(b);
        Button c=bt("📋 REKAP HARIAN"); c.setOnClickListener(v->records()); root.addView(c);
        Button d=bt("📊 REKAP BULANAN"); d.setOnClickListener(v->records()); root.addView(d);
        Button e=bt("⚙️ PENGATURAN"); e.setOnClickListener(v->settings()); root.addView(e);
        root.addView(tv("Versi 1.1 • Siap dikembangkan dengan iklan AdMob.",12));
    }

    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); root.addView(e); return e;
    }

    void input(){
        page("INPUT LEMBUR");
        EditText date=field("Tanggal (dd-mm-yyyy)");
        EditText name=field("Nama karyawan");
        EditText job=field("Jabatan / bagian");
        EditText masuk=field("Jam masuk (HH:mm)");
        EditText rest=field("Istirahat (menit), opsional — kosong = tanpa istirahat");
        EditText pulang=field("Jam pulang (HH:mm)");
        EditText ket=field("Pekerjaan / keterangan lembur");

        Button save=bt("SIMPAN & HITUNG LEMBUR");
        save.setOnClickListener(v->{
            try{
                int start=mins(masuk.getText().toString());
                int end=mins(pulang.getText().toString());
                String restText=rest.getText().toString().trim();
                int r=restText.isEmpty()?0:Integer.parseInt(restText);
                int effective=end-start; if(effective<0) effective+=1440;
                effective-=r;
                if(effective<0) effective=0;
                double ot=Math.max(0,effective-420)/60.0;
                String row=date.getText()+" | "+name.getText()+" | "+job.getText()
                    +" | "+String.format(Locale.US,"%.2f jam",ot)+" | "+ket.getText();
                records.add(row); saveData();
                Toast.makeText(this,"Data tersimpan. Lembur: "+
                    String.format(Locale.US,"%.2f jam",ot),Toast.LENGTH_LONG).show();
                home();
            }catch(Exception ex){
                Toast.makeText(this,"Periksa format jam dan menit.",Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(save);
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    int mins(String s){
        String[] p=s.trim().split(":");
        return Integer.parseInt(p[0])*60+Integer.parseInt(p[1]);
    }

    void employees(){
        page("DATA KARYAWAN");
        root.addView(tv("Daftar karyawan akan dikembangkan menjadi database permanen pada tahap berikutnya.",16));
        root.addView(tv("Untuk sekarang, nama dan jabatan dapat langsung dimasukkan saat input lembur.",14));
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void records(){
        page("REKAP LEMBUR");
        if(records.size()==0) root.addView(tv("Belum ada data lembur.",18));
        else{
            for(int i=0;i<records.size();i++){
                TextView x=tv((i+1)+". "+records.get(i),15);
                root.addView(x);
            }
            Button clear=bt("HAPUS SEMUA DATA");
            clear.setOnClickListener(v->{
                new AlertDialog.Builder(this).setTitle("Hapus data?")
                    .setMessage("Semua rekap lembur pada perangkat ini akan dihapus.")
                    .setNegativeButton("Batal",null)
                    .setPositiveButton("Hapus",(d,w)->{records.clear();saveData();records();}).show();
            });
            root.addView(clear);
        }
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void settings(){
        page("PENGATURAN");
        root.addView(tv("Jam kerja normal: 7 jam efektif (420 menit)",17));
        root.addView(tv("ID iklan AdMob belum diisi. Setelah akun AdMob siap, ID iklan dapat dipasang tanpa mengubah rumus lembur.",14));
        Button back=bt("KEMBALI"); back.setOnClickListener(v->home()); root.addView(back);
    }

    void saveData(){
        getSharedPreferences("data",MODE_PRIVATE).edit()
            .putString("records",String.join("\n",records)).apply();
    }
    void load(){
        String s=getSharedPreferences("data",MODE_PRIVATE).getString("records","");
        if(!s.isEmpty()) records.addAll(Arrays.asList(s.split("\\n")));
    }
}
